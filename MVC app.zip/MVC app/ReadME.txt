The Folder contains an app consisting a functioning To-Do List. 
Languages used: HTML, CSS, JavaScript
The app is created based on an MVC pattern

How to run on browser:

MVC app > View > html